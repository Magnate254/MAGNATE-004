import streamlit as st
import pandas as pd
import sqlite3

# Database setup
conn = sqlite3.connect("pos.db")
c = conn.cursor()
c.execute('''CREATE TABLE IF NOT EXISTS products
             (id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT, price REAL)''')
c.execute('''CREATE TABLE IF NOT EXISTS sales
             (id INTEGER PRIMARY KEY AUTOINCREMENT, product_name TEXT, quantity INTEGER, total REAL)''')
conn.commit()

# App UI
st.image("assets/logo.png", width=100)
st.title("ＭＡＧＮＡＴＥ POS")
st.caption("where freedom meets purpose")

menu = ["Add Product", "Sell Product", "View Sales"]
choice = st.sidebar.selectbox("Menu", menu)

if choice == "Add Product":
    st.subheader("Add New Product")
    name = st.text_input("Product Name")
    price = st.number_input("Price", min_value=0.0, step=0.01)
    if st.button("Add"):
        c.execute("INSERT INTO products (name, price) VALUES (?, ?)", (name, price))
        conn.commit()
        st.success(f"Added {name} at {price}")

elif choice == "Sell Product":
    st.subheader("Sell Product")
    products = pd.read_sql("SELECT * FROM products", conn)
    if not products.empty:
        product = st.selectbox("Select Product", products["name"])
        qty = st.number_input("Quantity", min_value=1, step=1)
        if st.button("Sell"):
            price = products.loc[products["name"] == product, "price"].values[0]
            total = price * qty
            c.execute("INSERT INTO sales (product_name, quantity, total) VALUES (?, ?, ?)", (product, qty, total))
            conn.commit()
            st.success(f"Sold {qty} x {product} for {total}")
    else:
        st.warning("No products found. Add some first.")

elif choice == "View Sales":
    st.subheader("Sales Records")
    sales = pd.read_sql("SELECT * FROM sales", conn)
    st.dataframe(sales)
    if not sales.empty:
        st.metric("Total Revenue", f"{sales['total'].sum():,.2f}")
